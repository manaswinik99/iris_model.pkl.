import joblib
from sklearn.datasets import load_iris

print("Starting model.py ...")

# Load the trained model
model = joblib.load("iris_model.pkl")

# Load dataset
iris = load_iris()
X = iris.data

# Predict first 5 rows
preds = model.predict(X[:5])
print("Predictions for first 5 rows:", preds.tolist())
